// app/api/proxy/route.ts

import { NextRequest, NextResponse } from "next/server";

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const CORS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};

// ── IP-session-bound CDN blocklist ────────────────────────────────────────────
// These CDNs sign tokens to the Playwright browser session.
// Proxying from the Node process (different IP socket) always 403/502.
// Block immediately — return fast 403 so client falls back without waiting.
const BLOCKED_CDN_HOSTS = [
  "stormvv.vodvidl.site",
  "vodvidl.site",
  "hakunaymatata.com",
];

function isBlockedHost(url: string): boolean {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return BLOCKED_CDN_HOSTS.some((b) => host === b || host.endsWith("." + b));
  } catch { return false; }
}

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: CORS });
}

// ── URL parser ────────────────────────────────────────────────────────────────
// Handles:
//   • Single encoding:   %2F → /
//   • Double encoding:   %252F → %2F → /
//   • Embedded params:   ?headers={...}&host=... stripped cleanly
//   • Iterative decode:  keeps decoding until stable
function parseCdnUrl(raw: string): {
  cleanUrl: string;
  embeddedHeaders: Record<string, string>;
} {
  let embeddedHeaders: Record<string, string> = {};

  // Split on first "?" to separate path from query
  const qIdx     = raw.indexOf("?");
  const rawPath  = qIdx === -1 ? raw      : raw.slice(0, qIdx);
  const rawQuery = qIdx === -1 ? ""       : raw.slice(qIdx + 1);

  // Parse query — strip ?headers= and ?host=, keep everything else
  const keepParams: string[] = [];
  for (const seg of rawQuery.split("&")) {
    if (!seg) continue;
    const eq  = seg.indexOf("=");
    const key = eq === -1 ? seg           : seg.slice(0, eq);
    const val = eq === -1 ? ""            : seg.slice(eq + 1);

    if (key === "headers") {
      // Try decoded JSON first, then raw
      try { embeddedHeaders = JSON.parse(decodeURIComponent(val)); } catch {
        try { embeddedHeaders = JSON.parse(val); } catch {}
      }
    } else if (key === "host") {
      // always drop — never rewrite Host header
    } else {
      keepParams.push(seg);
    }
  }

  // Iteratively decode path until stable — handles %252F → %2F → /
  let cleanPath = rawPath;
  for (let i = 0; i < 5; i++) {
    try {
      const next = decodeURIComponent(cleanPath);
      if (next === cleanPath) break; // stable
      cleanPath = next;
    } catch {
      break; // malformed — stop here
    }
  }

  // Sanity check: decoded path must still start with http
  if (!cleanPath.startsWith("http://") && !cleanPath.startsWith("https://")) {
    // Decoding broke the URL (e.g. a "/" appeared in the middle of the scheme)
    // Fall back to single-decode only
    try { cleanPath = decodeURIComponent(rawPath); } catch { cleanPath = rawPath; }
  }

  const cleanUrl = keepParams.length > 0
    ? `${cleanPath}?${keepParams.join("&")}`
    : cleanPath;

  return { cleanUrl, embeddedHeaders };
}

// ── M3U8 rewriter ─────────────────────────────────────────────────────────────
// Rewrites relative/absolute segment URLs to go through /api/proxy
// so HLS.js can fetch them without CORS issues.
function rewriteM3u8(text: string, baseUrl: string, headersJson: string): string {
  const noQuery = baseUrl.split("?")[0]!;
  const baseDir = noQuery.substring(0, noQuery.lastIndexOf("/") + 1);

  return text.split("\n").map((line) => {
    const t = line.trim();
    if (!t || t.startsWith("#")) return line;

    // Make absolute
    let abs: string;
    if (t.startsWith("http://") || t.startsWith("https://")) {
      abs = t;
    } else if (t.startsWith("//")) {
      abs = "https:" + t;
    } else {
      abs = baseDir + t;
    }

    // Strip any embedded ?headers=/?host= from segment URL
    const { cleanUrl } = parseCdnUrl(abs);
    abs = cleanUrl;

    // Don't proxy blocked CDN segments — fast fail
    if (isBlockedHost(abs)) {
      console.warn(`[proxy] skipping blocked CDN segment: ${abs.slice(0, 60)}`);
      return line; // return original — HLS.js will fail fast and trigger fallback
    }

    return `/api/proxy?url=${encodeURIComponent(abs)}&headers=${encodeURIComponent(headersJson)}`;
  }).join("\n");
}

// ── GET handler ───────────────────────────────────────────────────────────────
export async function GET(req: NextRequest) {
  const rawUrl      = req.nextUrl.searchParams.get("url") ?? "";
  const headersJson = req.nextUrl.searchParams.get("headers") ?? "{}";

  if (!rawUrl) {
    return NextResponse.json({ error: "Missing ?url=" }, { status: 400, headers: CORS });
  }

  let captured: Record<string, string> = {};
  try { captured = JSON.parse(headersJson); } catch {}

  const { cleanUrl, embeddedHeaders } = parseCdnUrl(rawUrl);

  if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
    return NextResponse.json({ error: "Only http/https allowed" }, { status: 400, headers: CORS });
  }

  // ── Block IP-bound CDNs immediately ──────────────────────────────────────
  if (isBlockedHost(cleanUrl)) {
    console.warn(`[proxy] blocked CDN — fast 403: ${cleanUrl.slice(0, 80)}`);
    return new NextResponse("CDN not proxiable (IP-session-bound token)", {
      status: 403,
      headers: CORS,
    });
  }

  // ── Build fetch headers ───────────────────────────────────────────────────
  // Priority: captured (from Playwright) > embedded (in URL params) > derived
  const referer =
    captured["referer"]        ?? captured["Referer"]        ??
    embeddedHeaders["referer"] ?? embeddedHeaders["Referer"] ?? "";

  const origin =
    captured["origin"]         ?? captured["Origin"]         ??
    embeddedHeaders["origin"]  ?? embeddedHeaders["Origin"]  ??
    (referer
      ? (() => { try { const u = new URL(referer); return `${u.protocol}//${u.host}`; } catch { return ""; } })()
      : "");

  const fetchHeaders: Record<string, string> = {
    // Use a real browser UA — strip HeadlessChrome markers that CDNs detect
    "user-agent":      UA,
    "accept":          "*/*",
    "accept-language": "en-US,en;q=0.9",
    // Don't send sec-ch-ua — HeadlessChrome in that header triggers CDN blocks
  };

  if (referer)            fetchHeaders["referer"]          = referer;
  if (origin)             fetchHeaders["origin"]           = origin;
  if (captured["cookie"]) fetchHeaders["cookie"]           = captured["cookie"];
  if (captured["range"])  fetchHeaders["range"]            = captured["range"];
  // Forward range from the browser's video element byte-range requests
  const rangeHeader = req.headers.get("range");
  if (rangeHeader && !fetchHeaders["range"]) fetchHeaders["range"] = rangeHeader;

  // ── Fetch upstream ────────────────────────────────────────────────────────
  try {
    const upstream = await fetch(cleanUrl, {
      headers: fetchHeaders,
      signal:  AbortSignal.timeout(30_000),
    });

    if (!upstream.ok) {
      console.error(`[proxy] ${upstream.status} for ${cleanUrl.slice(0, 100)}`);
      return new NextResponse(`Upstream ${upstream.status}`, {
        status: upstream.status,
        headers: CORS,
      });
    }

    const ct     = upstream.headers.get("content-type") ?? "";
    const isM3u8 =
      ct.includes("mpegurl") ||
      cleanUrl.includes(".m3u8") ||
      rawUrl.includes(".m3u8");

    if (isM3u8) {
      const text = await upstream.text();
      return new NextResponse(rewriteM3u8(text, cleanUrl, headersJson), {
        status: 200,
        headers: {
          ...CORS,
          "Content-Type":  "application/vnd.apple.mpegurl",
          "Cache-Control": "no-store",
        },
      });
    }

    // ── Stream binary response (mp4 segments, ts chunks, etc.) ───────────
    const responseHeaders: Record<string, string> = { ...CORS };
    const passthroughHeaders = [
      "content-type", "content-length", "content-range",
      "accept-ranges", "cache-control", "last-modified", "etag",
    ];
    for (const h of passthroughHeaders) {
      const v = upstream.headers.get(h);
      if (v) responseHeaders[h] = v;
    }
    if (!responseHeaders["content-type"]) responseHeaders["content-type"] = "video/mp2t";

    // Use 206 Partial Content if the upstream responded with it
    const status = upstream.status === 206 ? 206 : 200;

    return new NextResponse(upstream.body, { status, headers: responseHeaders });

  } catch (err) {
    console.error("[proxy] fetch error:", err);
    return new NextResponse("Proxy fetch failed", { status: 502, headers: CORS });
  }
}
