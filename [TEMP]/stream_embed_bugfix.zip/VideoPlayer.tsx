"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { Loader2 } from "lucide-react";

interface Props {
  movieId:           string | number;
  title:             string;
  poster?:           string;
  playing:           boolean;
  muted:             boolean;
  zoomed:            boolean;
  seekTo?:           number | null;
  onSeekComplete?:   () => void;
  onLoadingChange?:  (loading: boolean) => void;
  onTimeUpdate?:     (seconds: number) => void;
  onDurationChange?: (seconds: number) => void;
  onSourceReady?:    (sourceName: string) => void;
  onFallback?:       () => void;
}

type Phase = "fetching" | "playing";

function buildProxyUrl(streamUrl: string, headers: Record<string, string> | null): string {
  const h = encodeURIComponent(JSON.stringify(headers ?? {}));
  return `/api/proxy?url=${encodeURIComponent(streamUrl)}&headers=${h}`;
}

export default function VideoPlayer({
  movieId, poster, playing, muted, zoomed,
  seekTo, onSeekComplete,
  onLoadingChange, onTimeUpdate, onDurationChange,
  onSourceReady, onFallback,
}: Props) {
  const videoRef    = useRef<HTMLVideoElement>(null);
  const hlsRef      = useRef<any>(null);
  const activeRef   = useRef(true);
  const fellBackRef = useRef(false);

  const [phase,      setPhase]      = useState<Phase>("fetching");
  const [fetchLabel, setFetchLabel] = useState("Extracting stream…");

  const doFallback = useCallback(() => {
    if (!activeRef.current || fellBackRef.current) return;
    fellBackRef.current = true;
    onFallback?.();
  }, [onFallback]);

  const destroyHls = useCallback(() => {
    if (hlsRef.current) { hlsRef.current.destroy(); hlsRef.current = null; }
  }, []);

  const mountStream = useCallback(async (
    streamUrl: string,
    proxyHeaders: Record<string, string> | null,
    sourceName: string,
  ) => {
    const video = videoRef.current;
    if (!video || !activeRef.current) return;

    destroyHls();

    const proxied = buildProxyUrl(streamUrl, proxyHeaders);
    const isHls   = /\.m3u8/i.test(streamUrl);
    const isMp4   = /\.(mp4|mkv|webm)/i.test(streamUrl);

    if (isHls) {
      if (video.canPlayType("application/vnd.apple.mpegurl")) {
        // Safari native HLS
        video.src   = proxied;
        video.muted = muted;
        if (playing) video.play().catch(() => {});
        setPhase("playing");
        onLoadingChange?.(false);
        onSourceReady?.(sourceName);
      } else {
        // HLS.js
        try {
          const Hls = (await import("hls.js")).default;
          if (!Hls.isSupported()) { doFallback(); return; }

          const hls = new Hls({
            enableWorker:           true,
            maxBufferLength:        30,
            maxMaxBufferLength:     60,
            fragLoadingTimeOut:     30_000,
            manifestLoadingTimeOut: 20_000,
            levelLoadingTimeOut:    20_000,
          });
          hlsRef.current = hls;
          hls.loadSource(proxied);
          hls.attachMedia(video);

          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            if (!activeRef.current) return;
            video.muted = muted;
            if (playing) video.play().catch(() => {});
            setPhase("playing");
            onLoadingChange?.(false);
            onSourceReady?.(sourceName);
          });

          hls.on(Hls.Events.ERROR, (_: any, data: any) => {
            if (!data.fatal || !activeRef.current) return;
            console.error("[VideoPlayer] HLS fatal:", data.type, data.details);
            if (data.type === "mediaError") {
              hls.recoverMediaError();
            } else {
              doFallback();
            }
          });
        } catch { doFallback(); }
      }
      return; // HLS path: done
    }

    if (isMp4) {
      // Direct mp4/mkv/webm via proxy
      video.src   = proxied;
      video.muted = muted;
      if (playing) video.play().catch(() => {});
      setPhase("playing");
      onLoadingChange?.(false);
      onSourceReady?.(sourceName);
      return;
    }

    // Unknown format — fallback
    console.warn("[VideoPlayer] unknown stream format:", streamUrl.slice(0, 80));
    doFallback();
  }, [muted, playing, destroyHls, doFallback, onLoadingChange, onSourceReady]);

  const fetchStream = useCallback(async () => {
    if (!activeRef.current) return;
    fellBackRef.current = false;
    setPhase("fetching");
    setFetchLabel("Extracting stream…");
    onLoadingChange?.(true);

    try {
      setFetchLabel("Launching stream extractor…");

      // Always bust the cache on load so a previously bad/expired URL is never reused
      const res = await fetch(`/api/stream?id=${movieId}&bust=1`);

      if (!activeRef.current) return;
      if (!res.ok) { doFallback(); return; }

      const data = await res.json();
      if (!activeRef.current) return;

      if (!data.streamUrl) {
        console.warn("[VideoPlayer] no streamUrl → fallback");
        doFallback();
        return;
      }

      console.log(`[VideoPlayer] ✓ ${data.source}: ${data.streamUrl.slice(0, 80)}`);
      setFetchLabel(`Loading ${data.source}…`);
      await mountStream(data.streamUrl, data.proxyHeaders ?? null, data.source ?? "Stream");

    } catch (err) {
      console.error("[VideoPlayer] fetch error:", err);
      doFallback();
    }
  }, [movieId, mountStream, onLoadingChange, doFallback]);

  useEffect(() => {
    activeRef.current   = true;
    fellBackRef.current = false;
    fetchStream();
    return () => {
      activeRef.current = false;
      destroyHls();
    };
  }, [movieId]); // eslint-disable-line

  useEffect(() => {
    const v = videoRef.current;
    if (!v || phase !== "playing") return;
    playing ? v.play().catch(() => {}) : v.pause();
  }, [playing, phase]);

  useEffect(() => {
    const v = videoRef.current;
    if (v) v.muted = muted;
  }, [muted]);

  useEffect(() => {
    if (seekTo == null) return;
    const v = videoRef.current;
    if (v) v.currentTime = seekTo;
    onSeekComplete?.();
  }, [seekTo]); // eslint-disable-line

  return (
    <div className={`relative aspect-video overflow-hidden bg-black transition-transform duration-500 ${zoomed ? "scale-125" : "scale-100"}`}>

      <video
        ref={videoRef}
        className={`absolute inset-0 h-full w-full object-contain transition-opacity duration-700 ${phase === "playing" ? "opacity-100" : "opacity-0"}`}
        poster={poster ? `https://image.tmdb.org/t/p/w780${poster}` : undefined}
        playsInline
        muted={muted}
        onTimeUpdate={() => { const v = videoRef.current; if (v) onTimeUpdate?.(v.currentTime); }}
        onDurationChange={() => { const v = videoRef.current; if (v && isFinite(v.duration)) onDurationChange?.(v.duration); }}
        onError={(e) => {
          if (phase === "playing") {
            console.error("[VideoPlayer] <video> error:", (e.target as HTMLVideoElement).error?.message);
            doFallback();
          }
        }}
      />

      {phase === "fetching" && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black pointer-events-none">
          <img src="/logos/logo.png" alt="Logo" className="mb-6 w-28 animate-pulse" />
          <Loader2 size={58} className="animate-spin text-cyan-400" />
          <p className="mt-5 text-sm text-gray-400">{fetchLabel}</p>
          <p className="mt-2 text-xs text-gray-600">This may take up to 40s on first load</p>
        </div>
      )}
    </div>
  );
}
