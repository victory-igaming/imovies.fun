// src/app/api/stream/route.ts
//
// Uses stealth Playwright to bypass Cloudflare bot detection on VPS servers.
// Applies all known anti-detection techniques:
//   - Removes navigator.webdriver
//   - Fakes plugins, languages, permissions
//   - Randomises viewport/window size
//   - Adds human-like mouse movement + scroll before waiting for stream
//   - Uses realistic Chrome headers (no HeadlessChrome marker)

import { NextRequest, NextResponse } from "next/server";
import { chromium, type BrowserContext, type Page } from "playwright";

// ── Realistic Chrome UA (no HeadlessChrome) ──────────────────────────────────
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const SOURCES = (id: string) => [
  { name: "VidLink",   url: `https://vidlink.pro/movie/${id}?autoplay=1&player=jw&primaryColor=006fee` },
  { name: "VidLink 2", url: `https://vidlink.pro/movie/${id}?autoplay=1&primaryColor=006fee` },
  { name: "Videasy",   url: `https://player.videasy.net/movie/${id}` },
  { name: "VidKing",   url: `https://www.vidking.net/embed/movie/${id}?autoplay=1` },
  { name: "NontonGo",  url: `https://www.nontongo.win/embed/movie/${id}?autoplay=1` },
  { name: "VidSrc v2", url: `https://vidsrc.cc/v2/embed/movie/${id}?autoPlay=true` },
  { name: "VidSrc v3", url: `https://vidsrc.cc/v3/embed/movie/${id}?autoPlay=true` },
  { name: "MoviesAPI", url: `https://moviesapi.club/movie/${id}?autoplay=1` },
];

const EMBEDS = (id: string) => [
  { name: "Videasy",   url: `https://player.videasy.net/movie/${id}` },
  { name: "VidLink",   url: `https://vidlink.pro/movie/${id}?autoplay=1&player=jw&primaryColor=006fee` },
  { name: "VidSrc V3", url: `https://vidsrc.cc/v3/embed/movie/${id}?autoPlay=true` },
  { name: "VidSrc V2", url: `https://vidsrc.cc/v2/embed/movie/${id}?autoPlay=true` },
  { name: "NontonGo",  url: `https://www.nontongo.win/embed/movie/${id}?autoplay=1` },
  { name: "VidKing",   url: `https://www.vidking.net/embed/movie/${id}?autoplay=1` },
  { name: "MoviesAPI", url: `https://moviesapi.club/movie/${id}?autoplay=1` },
  { name: "2Embed",    url: `https://2embed.org/embed/movie/tmdb/${id}` },
];

const MEDIA_RE = /\.(m3u8|mp4|mkv|webm)/i;
const SKIP_RE  = /google|facebook|doubleclick|gstatic|fonts\.|analytics|tracking|recaptcha|googlevideo\.com/i;

// IP-session-bound CDNs — never proxiable
const BLOCKED_CDN_HOSTS = ["stormvv.vodvidl.site", "vodvidl.site", "hakunaymatata.com"];
function isBlockedCdn(url: string): boolean {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return BLOCKED_CDN_HOSTS.some((b) => host === b || host.endsWith("." + b));
  } catch { return false; }
}

const CACHE     = new Map<string, { data: StreamApiResponse; expires: number }>();
const CACHE_TTL = 10 * 60 * 1000;

export interface StreamApiResponse {
  streamUrl:    string | null;
  proxyHeaders: Record<string, string> | null;
  source:       string | null;
  embedSources: Array<{ name: string; url: string }>;
  embedUrl:     string;
}

// ── Stealth script injected into every page ───────────────────────────────────
// Patches all the properties Cloudflare / bot-detection scripts check.
const STEALTH_SCRIPT = `
  // 1. Remove webdriver flag
  Object.defineProperty(navigator, 'webdriver', { get: () => undefined });

  // 2. Fake plugins (headless has none)
  Object.defineProperty(navigator, 'plugins', {
    get: () => {
      const arr = [
        { name: 'Chrome PDF Plugin',       filename: 'internal-pdf-viewer',    description: 'Portable Document Format' },
        { name: 'Chrome PDF Viewer',        filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai', description: '' },
        { name: 'Native Client',            filename: 'internal-nacl-plugin',   description: '' },
      ];
      arr.item = (i) => arr[i];
      arr.namedItem = (n) => arr.find(p => p.name === n) || null;
      arr.refresh = () => {};
      Object.setPrototypeOf(arr, PluginArray.prototype);
      return arr;
    }
  });

  // 3. Fake languages
  Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });

  // 4. Fake screen/window metrics (match a real 1920×1080 monitor)
  Object.defineProperty(screen, 'width',       { get: () => 1920 });
  Object.defineProperty(screen, 'height',      { get: () => 1080 });
  Object.defineProperty(screen, 'availWidth',  { get: () => 1920 });
  Object.defineProperty(screen, 'availHeight', { get: () => 1040 });
  Object.defineProperty(screen, 'colorDepth',  { get: () => 24 });
  Object.defineProperty(screen, 'pixelDepth',  { get: () => 24 });

  // 5. Fake permissions query (headless returns 'denied' for notifications)
  const origQuery = window.navigator.permissions?.query?.bind(navigator.permissions);
  if (origQuery) {
    navigator.permissions.query = (params) => {
      if (params.name === 'notifications') {
        return Promise.resolve({ state: 'default', onchange: null });
      }
      return origQuery(params);
    };
  }

  // 6. Fake chrome runtime object
  if (!window.chrome) {
    window.chrome = {
      runtime: {
        PlatformOs: { MAC: 'mac', WIN: 'win', ANDROID: 'android', CROS: 'cros', LINUX: 'linux', OPENBSD: 'openbsd' },
        PlatformArch: { ARM: 'arm', X86_32: 'x86-32', X86_64: 'x86-64' },
        PlatformNaclArch: { ARM: 'arm', X86_32: 'x86-32', X86_64: 'x86-64' },
        RequestUpdateCheckStatus: { THROTTLED: 'throttled', NO_UPDATE: 'no_update', UPDATE_AVAILABLE: 'update_available' },
        OnInstalledReason: { INSTALL: 'install', UPDATE: 'update', CHROME_UPDATE: 'chrome_update', SHARED_MODULE_UPDATE: 'shared_module_update' },
        OnRestartRequiredReason: { APP_UPDATE: 'app_update', OS_UPDATE: 'os_update', PERIODIC: 'periodic' },
      },
    };
  }

  // 7. Spoof connection type
  Object.defineProperty(navigator, 'connection', {
    get: () => ({ effectiveType: '4g', rtt: 50, downlink: 10, saveData: false }),
  });

  // 8. Realistic hardware concurrency / memory
  Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
  Object.defineProperty(navigator, 'deviceMemory',        { get: () => 8 });
`;

// ── Human-like behaviour simulation ──────────────────────────────────────────
async function simulateHuman(page: Page): Promise<void> {
  try {
    // Random mouse movements
    await page.mouse.move(
      200 + Math.random() * 400,
      100 + Math.random() * 200,
      { steps: 10 }
    );
    await page.waitForTimeout(300 + Math.random() * 400);

    // Scroll down a bit
    await page.evaluate(() => window.scrollBy(0, 150 + Math.random() * 200));
    await page.waitForTimeout(200 + Math.random() * 300);

    // Move mouse again
    await page.mouse.move(
      300 + Math.random() * 300,
      300 + Math.random() * 200,
      { steps: 8 }
    );
    await page.waitForTimeout(200 + Math.random() * 200);
  } catch { /* ignore — page may have navigated */ }
}

// ── Create a stealth browser context ─────────────────────────────────────────
async function createStealthContext(browser: any): Promise<BrowserContext> {
  // Randomise viewport slightly so all requests don't look identical
  const width  = 1280 + Math.floor(Math.random() * 200);
  const height = 720  + Math.floor(Math.random() * 100);

  const ctx = await browser.newContext({
    userAgent: UA,
    viewport:  { width, height },
    locale:    "en-US",
    timezoneId: "America/New_York",
    geolocation: { latitude: 40.7128, longitude: -74.0060 }, // New York
    permissions: ["geolocation"],
    extraHTTPHeaders: {
      "Accept-Language": "en-US,en;q=0.9",
      "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
      "sec-ch-ua":          `"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"`,
      "sec-ch-ua-mobile":   "?0",
      "sec-ch-ua-platform": '"Windows"',
      "Upgrade-Insecure-Requests": "1",
    },
  });

  // Inject stealth script before any page script runs
  await ctx.addInitScript(STEALTH_SCRIPT);

  return ctx;
}

// ── Server-side probe ─────────────────────────────────────────────────────────
async function probeUrl(url: string, headers: Record<string, string>): Promise<boolean> {
  let cleanUrl = url;
  try {
    const u = new URL(url);
    u.searchParams.delete("headers");
    u.searchParams.delete("host");
    cleanUrl = u.toString();
  } catch { /* keep original */ }

  const probeHeaders: Record<string, string> = { "User-Agent": UA, "Range": "bytes=0-1023" };
  if (headers["referer"]) probeHeaders["Referer"] = headers["referer"];
  if (headers["origin"])  probeHeaders["Origin"]  = headers["origin"];

  try {
    const res = await fetch(cleanUrl, {
      method:  "GET",
      headers: probeHeaders,
      signal:  AbortSignal.timeout(8_000),
    });
    const ok = [200, 206, 301, 302].includes(res.status);
    if (!ok) console.warn(`[stream] probe ${res.status} → ${cleanUrl.slice(0, 70)}`);
    try { const r = res.body?.getReader(); if (r) { await r.read(); r.cancel(); } } catch {}
    return ok;
  } catch (err) {
    console.warn(`[stream] probe error → ${cleanUrl.slice(0, 60)}:`, (err as Error).message);
    return false;
  }
}

// ── Main extraction ───────────────────────────────────────────────────────────
async function extractStream(id: string): Promise<{
  streamUrl: string;
  proxyHeaders: Record<string, string>;
  source: string;
} | null> {
  const browser = await chromium.launch({
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-blink-features=AutomationControlled",  // KEY: removes automation flag
      "--disable-dev-shm-usage",
      "--disable-gpu",
      "--no-first-run",
      "--no-default-browser-check",
      "--disable-extensions",
      "--disable-background-networking",
      "--disable-sync",
      "--metrics-recording-only",
      "--disable-default-apps",
      "--mute-audio",
      "--hide-scrollbars",
      "--disable-web-security",
      "--allow-running-insecure-content",
    ],
  });

  try {
    for (const src of SOURCES(id)) {
      let ctx: BrowserContext | null = null;
      let page: Page | null = null;

      try {
        ctx  = await createStealthContext(browser);
        page = await ctx.newPage();
      } catch (ctxErr) {
        console.error(`[stream] context error for ${src.name}:`, ctxErr);
        continue;
      }

      const candidates: Array<{ url: string; headers: Record<string, string> }> = [];

      page.on("request", (req) => {
        const url = req.url();
        if (SKIP_RE.test(url))       return;
        if (isBlockedCdn(url))       return;
        if (!MEDIA_RE.test(url))     return;
        if (candidates.some((c) => c.url === url)) return;
        candidates.push({ url, headers: req.headers() });
      });

      try {
        await page.goto(src.url, { timeout: 30_000, waitUntil: "domcontentloaded" });

        // Simulate human interaction — this is what bypasses Cloudflare's JS challenge
        await simulateHuman(page);

        // Poll for media URLs up to 30s
        const deadline = Date.now() + 30_000;
        while (Date.now() < deadline) {
          if (candidates.length > 0) break;
          await page.waitForTimeout(500);
        }
      } catch (navErr) {
        console.warn(`[stream] nav error ${src.name}:`, (navErr as Error).message);
      } finally {
        try { await page?.close(); }  catch {}
        try { await ctx?.close();  }  catch {}
      }

      console.log(`[stream] ${src.name}: ${candidates.length} candidate(s)`);

      for (const c of candidates) {
        const reachable = await probeUrl(c.url, c.headers);
        if (reachable) {
          console.log(`[stream] ✓ ${src.name} → ${c.url.slice(0, 80)}`);
          return { streamUrl: c.url, proxyHeaders: c.headers, source: src.name };
        }
        console.warn(`[stream] ✗ probe failed → ${c.url.slice(0, 60)}`);
      }

      console.warn(`[stream] ✗ ${src.name} — no reachable URL`);
    }
  } finally {
    try { await browser.close(); } catch {}
  }

  return null;
}

// ── Route handler ─────────────────────────────────────────────────────────────
export async function GET(req: NextRequest) {
  const id   = req.nextUrl.searchParams.get("id");
  const bust = req.nextUrl.searchParams.get("bust");
  if (!id) return NextResponse.json({ error: "Missing ?id=" }, { status: 400 });

  if (!bust) {
    const hit = CACHE.get(id);
    if (hit && hit.expires > Date.now()) {
      return NextResponse.json(hit.data, {
        headers: { "X-Cache": "HIT", "Cache-Control": "public, max-age=600" },
      });
    }
  } else {
    CACHE.delete(id);
    console.log(`[stream] cache busted for id=${id}`);
  }

  const embedSources = EMBEDS(id);
  const embedUrl     = embedSources[0]!.url;

  try {
    const result = await extractStream(id);

    if (result) {
      const data: StreamApiResponse = { ...result, embedSources, embedUrl };
      CACHE.set(id, { data, expires: Date.now() + CACHE_TTL });
      return NextResponse.json(data, {
        headers: { "Cache-Control": "public, max-age=600, stale-while-revalidate=60" },
      });
    }

    const data: StreamApiResponse = {
      streamUrl: null, proxyHeaders: null, source: null, embedSources, embedUrl,
    };
    return NextResponse.json(data, { headers: { "Cache-Control": "no-store" } });

  } catch (err: any) {
    console.error("[stream] error:", err?.message, err?.stack);
    const data: StreamApiResponse = {
      streamUrl: null, proxyHeaders: null, source: null, embedSources, embedUrl,
    };
    return NextResponse.json(data, { status: 200, headers: { "Cache-Control": "no-store" } });
  }
}
